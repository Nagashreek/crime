function checkEmpty(data)
{
	if(data==undefined || data == null || data.trim() == '')
			return false;			
	return true;
}
function checkPwdLength(data)
{
	if(data==undefined && data == null || data.trim() == '')
			return false;
	else if(data.length<6)
			return false;			
	return true;
}
function checkMobileNo(data)
{
	if(data==undefined && data == null || data.trim() == '')
	    return false;	
	else if(Number.isInteger(data))
		return false;	
	else if(data.length!=10)  	
	    return false;			
	return true;
}



//crime registration


function checkAll()
{
	var comdate=document.getElementById("Date").value;
	if(checkEmpty(comdate)==false)
	{
		alert("Please enter Date");
		return false;
	}
	var det=document.getElementById("Victdet").value;
	if(checkEmpty(det)==false)
	{
		alert("Please enter victim details");
		return false;
	}
	var add=document.getElementById("Loc").value;
	if(checkEmpty(add)==false)
	{
		alert("Please enter Location");
		return false;
	}
	var det1=document.getElementById("Comdet").value;
	if(checkEmpty(det1)==false)
	{
		alert("Please enter complaint details");
		return false;
	}
	var email=document.getElementById("Email").value;
	if(checkEmpty(email)==false)
	{
		alert("Please enter email");
		return false;
	}
	return true;	
}



//crime deletion


function checkAll1()
{
	var id=document.getElementById("Comid").value;
	if(checkEmpty(id)==false)
	{
		alert("Please enter your ComplaintID");
		return false;
	}
	var det1=document.getElementById("Comdet").value;
	if(checkEmpty(det1)==false)
	{
		alert("Please enter complaint details");
		return false;
	}
	return true;	
}



//editing crime


function checkAll2()
{
	var id=document.getElementById("Comid").value;
	if(checkEmpty(id)==false)
	{
		alert("Please enter your ComplaintID");
		return false;
	}
	var det1=document.getElementById("Comdet").value;
	if(checkEmpty(det1)==false)
	{
		alert("Please enter complaint details");
		return false;
	}
	var add=document.getElementById("Loc").value;
	if(checkEmpty(add)==false)
	{
		alert("Please enter Location");
		return false;
	}
	var det=document.getElementById("Victdet").value;
	if(checkEmpty(det)==false)
	{
		alert("Please enter victim details");
		return false;
	}
	var comdate=document.getElementById("Date").value;
	if(checkEmpty(comdate)==false)
	{
		alert("Please enter Date");
		return false;
	}
	
	return true;
	
}



//closing crime


function checkAll3()
{
	
	var id=document.getElementById("Comid").value;
	if(checkEmpty(id)==false)
	{
		alert("Please enter your ComplaintID");
		return false;
	}
	var canRB=document.getElementById("Closed");
	var penRB=document.getElementById("Pending");
	if(canRB.checked==false && penRB.checked==false)
	{
		alert("Please select YES/NO");
		return false;
	}
	var can1=document.getElementById("Can").value;
	if(checkEmpty(can1)==false)
	{
		alert("Please enter reason");
		return false;
	}

    return true;
}


//user feedback


function checkAll4()
{
	
	var id=document.getElementById("Comid").value;
	if(checkEmpty(id)==false)
	{
		alert("Please enter your ComplaintID");
		return false;
	}
	var fee=document.getElementById("Feed1").value;
	if(checkEmpty(fee)==false)
	{
		alert("Please enter your feedback");
		return false;
	}

    return true;
}


//admin feedback


function checkAll5()
{
	
	var id=document.getElementById("Comid").value;
	if(checkEmpty(id)==false)
	{
		alert("Please enter your ComplaintID");
		return false;
	}
	var po=document.getElementById("Police").value;
	if(checkEmpty(po)==false)
	{
		alert("Please enter police name");
		return false;
	}
	var fee=document.getElementById("Feed").value;
	if(checkEmpty(fee)==false)
	{
		alert("Please enter your feedback");
		return false;
	}

    return true;
}

