package crime.model;

public class Reportmodel {
	    private String rpt_id;
		private String date_rpt;
		private String rpt_det;
		private String rep_auty;
		private int com_id;
		 public Reportmodel()
		 {
			 
		 }	
		public int getCom_id() {
			return com_id;
		}
		public void setCom_id(int com_id) {
			this.com_id = com_id;
		}
		public String getRpt_id() {
			return rpt_id;
		}
		public void setRpt_id(String rpt_id) {
			this.rpt_id = rpt_id;
		}

		public String getDate_rpt() {
			return date_rpt;
		}

		public void setDate_rpt(String date_rpt) {
			this.date_rpt = date_rpt;
		}

		public String getRpt_det() {
			return rpt_det;
		}

		public void setRpt_det(String rpt_det) {
			this.rpt_det = rpt_det;
		}

		public String getRep_auty() {
			return rep_auty;
		}

		public void setRep_auty(String rep_auty) {
			this.rep_auty = rep_auty;
		}
		
}
